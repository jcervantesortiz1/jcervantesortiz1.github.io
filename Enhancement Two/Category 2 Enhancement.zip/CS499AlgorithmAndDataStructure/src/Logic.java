// CS-499 Milestone 2
// Juan Cervantes Ortiz

import java.util.HashMap;
import java.util.Scanner;

public class Logic {
	// Creates the HashMaps need for the system
    private static HashMap<String, Dog> dogMap = new HashMap<>();
    private static HashMap<String, Monkey> monkeyMap = new HashMap<>();

    // Adds dogs to the map for testing/initialization
    public void initializeDogHashMap() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");

        dogMap.put(dog1.getName(), dog1);
        dogMap.put(dog2.getName(), dog2);
        dogMap.put(dog3.getName(), dog3);
    }

    // Adds monkeys to the map for testing/initialization
    public void initializeMonkeyHashMap() {
        Monkey monkey1 = new Monkey("M1", "Capuchin", "male", "2", "7.8", "04-24-2022", "United States", "in service", false, "United States", "14.8", "15.6", "17.2");
        Monkey monkey2 = new Monkey("M2", "Tamarin", "male", "3", "34.3", "02-12-2019", "Canada", "in service", true, "United States", "3 in", "24 in", "35 lbs");
        Monkey monkey3 = new Monkey("M3", "Tamarin", "male", "3", "34.3", "02-12-2019", "Canada", "in service", false, "Canada", "3 in", "24 in", "35 lbs");

        
        monkeyMap.put(monkey1.getName(), monkey1);
        monkeyMap.put(monkey2.getName(), monkey2);
        monkeyMap.put(monkey3.getName(), monkey3);
    }

    /**
     * This method adds a new dog to the HashMap
     * @param scanner
     */
    public void intakeNewDog(Scanner scanner) {
        scanner.nextLine(); // clears out input so that the dog's name can be properly read in
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        if (dogMap.containsKey(name)) {
            System.out.println("\n\nThis dog is already in our system\n\n");
            return; // returns to menu
        }

        System.out.println("Enter dog's breed");
        String breed = scanner.nextLine();
        System.out.println("Gender: ");
        String gender = scanner.nextLine();
        System.out.println("Age: ");
        String age = scanner.nextLine();
        System.out.println("Weight: ");
        String weight = scanner.nextLine();
        System.out.println("Acquisition date: ");
        String acquisitionDate = scanner.nextLine();
        System.out.println("Acquisition country: ");
        String country = scanner.nextLine();
        System.out.println("Training status: ");
        String trainingStatus = scanner.nextLine();
        System.out.println("Reserved? (1 for true 0 for false)");
        String reservedAns = scanner.nextLine();

        boolean reserved = reservedAns.equals("1");

        System.out.println("In service country: ");
        String countryServ = scanner.nextLine();

        Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, country, trainingStatus, reserved, countryServ);
        dogMap.put(name, newDog);
    }

    /**
     * This method adds a new monkey to the HashMap
     * @param scanner
     */
    public void intakeNewMonkey(Scanner scanner) {
        scanner.nextLine(); // clears out the input so that the monkey's name can be read in properly
        System.out.println("What is the monkey's name: ");
        String name = scanner.nextLine();
        if (monkeyMap.containsKey(name)) {
            System.out.println("\n\nThis Monkey is already in our system\n\n");
            return; // returns to menu
        }

        System.out.println("What is the monkey's species?");
        String species = scanner.nextLine();
        if (!(species.equalsIgnoreCase("Capuchin")) && !(species.equalsIgnoreCase("Guenon"))
                && !(species.equalsIgnoreCase("Macaque")) && !(species.equalsIgnoreCase("Marmoset"))
                && !(species.equalsIgnoreCase("Squirrel Monkey")) && !(species.equalsIgnoreCase("Tamarin"))) {
            System.out.println("\n\nThis monkey's species is not allowed\n\n");
            return;
        }

        System.out.println("Gender: ");
        String gender = scanner.nextLine();
        System.out.println("Age: ");
        String age = scanner.nextLine();
        System.out.println("Weight: ");
        String weight = scanner.nextLine();
        System.out.println("Acquisition date: ");
        String acquisition = scanner.nextLine();
        System.out.println("Acquisition country: ");
        String country = scanner.nextLine();
        System.out.println("Training status: ");
        String status = scanner.nextLine();
        System.out.println("Reserved? (1 for true 0 for false)");
        String reservedAns = scanner.nextLine();
        boolean reserved = reservedAns.equals("1");

        System.out.println("In service country: ");
        String countryServ = scanner.nextLine();
        System.out.println("Tail length: ");
        String tailLength = scanner.nextLine();
        System.out.println("Height");
        String height = scanner.nextLine();
        System.out.println("Body length");
        String bodyLength = scanner.nextLine();

        Monkey newMonkey = new Monkey(name, species, gender, age, weight, acquisition, country, status, reserved, countryServ, tailLength, height, bodyLength);
        monkeyMap.put(name, newMonkey);
    }

    /**
     * This method deletes an animal from our HashMap
     * @param scanner
     */
    public void deleteAnimal(Scanner scan) {
    	
        try {
            System.out.println("Do you want to remove a dog or monkey?");
            String input = scan.next();
            if (input.equalsIgnoreCase("dog")) {
                System.out.println("What dog would you like to delete?");
                String dogName = scan.next();
                if (dogMap.containsKey(dogName)) {
                    dogMap.remove(dogName);
                    System.out.println(dogName + " has been deleted.");
                } else {
                    System.out.println("Dog not found.");
                }
            } else if (input.equalsIgnoreCase("monkey")) {
                System.out.println("What monkey would you like to delete?");
                String monkeyName = scan.next();
                if (monkeyMap.containsKey(monkeyName)) {
                    monkeyMap.remove(monkeyName);
                    System.out.println(monkeyName + " has been deleted.");
                } else {
                    System.out.println("Monkey not found.");
                }
                
            } else {
            	System.out.println("That animal is not in out system");
            }
        } catch (Exception e){
        	System.out.println("Invalid option");
        }
    }

    /**
     * This method will ask the user what animal they want to reserve,
     * and in what country. It then searches the map to see if there
     * are any animals that meat the requirements
     * if it does then it will update its reserved variable to true.
     * @param scanner
     */
    public void reserveAnimal(Scanner scanner) {
    	try {
	        scanner.nextLine(); // clears the input buffer
	
	        System.out.println("Enter animal type (Dog or Monkey): ");
	        String animalType = scanner.nextLine();
	        System.out.println("Enter the animal's acquisition country: ");
	        String country = scanner.nextLine();
	
	        if (animalType.equalsIgnoreCase("dog")) {
	            for (Dog dog : dogMap.values()) {
	                if (dog.getInServiceLocation().equalsIgnoreCase(country)
	                        && dog.getTrainingStatus().equalsIgnoreCase("in service")
	                        && !dog.getReserved()) {
	                    dog.setReserved(true);
	                    System.out.println(dog.getName() + " is now reserved");
	                    break;
	                }
	            }
	        }
	
	        if (animalType.equalsIgnoreCase("monkey")) {
	            for (Monkey monkey : monkeyMap.values()) {
	                if (monkey.getInServiceLocation().equalsIgnoreCase(country)
	                        && monkey.getTrainingStatus().equalsIgnoreCase("in service")
	                        && !monkey.getReserved()) {
	                    monkey.setReserved(true);
	                    System.out.println(monkey.getName() + " is now reserved");
	                    break;
	                }
	            }
	        }
	        
	        if (!animalType.equalsIgnoreCase("dog") && !animalType.equalsIgnoreCase("monkey")) {
	        	System.out.println("That animal does not exist in our system");
	        }
    	} catch (Exception e){
        	System.out.println("An error has occured, please try your request again");
        }
    }

    /**
     * Prints all of the dogs in the HashMap
     * It will print out the dogs name, training status, 
     * acquisition location, and whether they are reserved or not
     */
    public void printDogs() {
    	try {
	        for (Dog dog : dogMap.values()) {
	            System.out.println("Name: " + dog.getName() + " Training Status: " + dog.getTrainingStatus() + " Acquisition Location: " + dog.getAcquisitionLocation() + " Reserved: " + dog.getReserved());
	        }
    	} catch (Exception e){
        	System.out.println("An error has occured, please try your request again");
        }
    }

    /**
     * Prints all of the monkeys in the HashMap
     * It will print out the monkeys name, training status, 
     * acquisition location, and whether they are reserved or not
     */
    public void printMonkeys() {
    	try {
	        for (Monkey monkey : monkeyMap.values()) {
	            System.out.println("Name: " + monkey.getName() + " Training Status: " + monkey.getTrainingStatus() + " Acquisition Location: " + monkey.getAcquisitionLocation() + " Reserved: " + monkey.getReserved());
	        }
    	} catch (Exception e){
        	System.out.println("An error has occured, please try your request again");
        }
    }

    /**
     * Prints all of the available animals in the HashMap
     * The animal must be in service and not reserved (AKA available)
     * It will print out the animals name, training status, 
     * acquisition location, and whether they are reserved or not
     */
    public void printAvailableAnimals() {
    	try {
	        for (Dog dog : dogMap.values()) {
	            if (dog.getTrainingStatus().equalsIgnoreCase("in service") && !dog.getReserved()) {
	                System.out.println("Name: " + dog.getName() + " Training Status: " + dog.getTrainingStatus() + " Acquisition Location: " + dog.getAcquisitionLocation() + " Reserved: " + dog.getReserved());
	            }
	        }
	        for (Monkey monkey : monkeyMap.values()) {
	            if (monkey.getTrainingStatus().equalsIgnoreCase("in service") && !monkey.getReserved()) {
	                System.out.println("Name: " + monkey.getName() + " Training Status: " + monkey.getTrainingStatus() + " Acquisition Location: " + monkey.getAcquisitionLocation() + " Reserved: " + monkey.getReserved());
	            }
	        }
    	} catch (Exception e){
        	System.out.println("An error has occured, please try your request again");
        }
    }
}

