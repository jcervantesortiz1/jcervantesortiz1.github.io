
public class Dog extends RescueAnimal {

    // Instance variable
    private String breed;
    
    // sets default values for the dog specific variable
 	public Dog() { 
 		breed = "Unknown";
 	}

    // Constructor
    public Dog(String name, String breed, String gender, String age,
    String weight, String acquisitionDate, String acquisitionCountry,
	String trainingStatus, boolean reserved, String inServiceCountry) {
        setName(name);
        setBreed(breed);
        setGender(gender); 
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);

    }

    // Returns the breed
    public String getBreed() {
        return breed;
    }

    // Sets the dog breed to the value passed in
    public void setBreed(String dogBreed) {
        breed = dogBreed;
    }

}
