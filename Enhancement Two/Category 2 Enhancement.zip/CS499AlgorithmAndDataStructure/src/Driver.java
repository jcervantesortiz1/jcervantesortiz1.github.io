// CS-499 Milestone 2
// Juan Cervantes Ortiz

import java.util.Scanner;

public class Driver {
    static Logic logic = new Logic();

    public static void main(String[] args) {
 
    	//initializes the dog and monkey maps
        logic.initializeDogHashMap();
        logic.initializeMonkeyHashMap();
        
        // creates scanner to read user input
        Scanner scan = new Scanner(System.in);
        // sets user input as input so that it can be compared
        char input;

        // do loop that will check input
        do {
        	
            // runs the displayMenu method to show options
            displayMenu();
            // scans the value entered, it will also ignore other inputs aside from the first character
            input = scan.next().charAt(0);

            // switch cases that check input and run appropriate method
            switch (input) {
                case '1':
                    logic.intakeNewDog(scan);
                    break;

                case '2':
                    logic.intakeNewMonkey(scan);
                    break;
                case '3':
                    logic.reserveAnimal(scan);
                    break;
                case '4':
                	logic.printDogs();
                    break;
                case '5':
                    //printAnimals("monkey");
                    logic.printMonkeys();
                    break;
                case '6':
                    //printAnimals("available");
                    logic.printAvailableAnimals();
                    break;
                case 'd':
                	logic.deleteAnimal(scan);
                	break;
                // if the input is q it will notify the user and then end the program
                case 'q':
                    System.out.println("You have exited the application");
                    break;

                // any other input other than [1,2,3,4,5,6,q] will result in the error message and will loop back to the begining of do loop
                default:
                    System.out.println("Invalid option, enter valid option");
                    break;

            }
        // ensures that the do loop continues to run while input is NOT q
        } while (input != 'q');
        
        scan.close();
    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu Updated");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println("[d] To remove an animal");
        System.out.println();
        System.out.println("Enter a menu selection");
    }

}
