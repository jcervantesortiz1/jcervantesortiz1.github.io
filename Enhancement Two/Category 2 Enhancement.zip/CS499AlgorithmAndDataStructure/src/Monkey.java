// sets up monkey class and connects it to rescueAnimal
public class Monkey extends RescueAnimal{
	// sets up private variables
	private String species, tailLength, height, bodyLength;
	
	// sets default values for the monkey specific variables
	public Monkey() { 
		species = "Unknown";
		tailLength = "Unkown";
		height = "Unknown";
		bodyLength = "Unknown";
	}
	
	// creates a Monkey while also adding all the specified parameters
	public Monkey(String name, String species, String gender, String age,
    String weight, String acquisitionDate, String acquisitionCountry,
	String trainingStatus, boolean reserved, String inServiceCountry, 
	String tailLength, String height, String bodyLength) {
        setName(name);
        setSpecies(species);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
        setTailLength(tailLength);
		setHeight(height);
		setBodyLength(bodyLength);
	}

	// retrieves the species of the monkey
	public String getSpecies() {
		return species;
	}
	
	// sets what species the monkey is
	public void setSpecies(String species) {
		this.species = species;
	}
	 
	// retrieves the tail length
	public String getTailLength() {
		return tailLength;
	}
	
	// sets the tail length of the monkey with the value passed in
	public void setTailLength(String tailLength) {
		this.tailLength = tailLength;
	}
	
	// retrieves the height of the monkey
	public String getHeight() {
		return height;
	}
	
	// sets the height of the monkeky with the value passed in
	public void setHeight(String height) {
		this.height = height;
	}
	
	// retrieves the body length of the monkey
	public String getBodyLength() {
		return bodyLength;
	}
	
	// sets the body length with the value passed in
	public void setBodyLength(String bodyLength) {
		this.bodyLength = bodyLength;
	}
}
