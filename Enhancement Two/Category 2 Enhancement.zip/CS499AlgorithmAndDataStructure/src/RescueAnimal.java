
import java.lang.String;

public class RescueAnimal {

    // Instance variables
    private String name;
    private String animalType;
    private String gender;
    private String age;
    private String weight;
    private String acquisitionDate;
    private String acquisitionCountry;
	private String trainingStatus;
    private boolean reserved;
	private String inServiceCountry;


    // Constructor
    public RescueAnimal() {
    }

    // Gets the animals name
	public String getName() {
		return name;
	}

	// Sets the animal name with the value passed in
	public void setName(String name) {
		this.name = name;
	}

	// Gets the animals type
	public String getAnimalType() {
		return animalType;
	}

	// Sets the animal type with the value passed in
	public void setAnimalType(String animalType) {
		this.animalType = animalType;
	}

	// Gets the animals gender
	public String getGender() {
		return gender;
	}

	// Sets the animal gender with the value passed in
	public void setGender(String gender) {
		this.gender = gender;
	}

	// Gets the animal age
	public String getAge() {
		return age;
	}

	// Sets the animal age
	public void setAge(String age) {
		this.age = age;
	}

	// Gets the animals weight
	public String getWeight() {
		return weight;
	}

	// Sets the animals weight with the value passed in
	public void setWeight(String weight) {
		this.weight = weight;
	}

	// Gets the animals acquisition date
	public String getAcquisitionDate() {
		return acquisitionDate;
	}

	// Sets the animals acquisition date with the value passed in
	public void setAcquisitionDate(String acquisitionDate) {
		this.acquisitionDate = acquisitionDate;
	}

	// Gets the animals acquisition location
	public String getAcquisitionLocation() {
		return acquisitionCountry;
	}

	// Sets the animal acquisition location with the value passed in
	public void setAcquisitionLocation(String acquisitionCountry) {
		this.acquisitionCountry = acquisitionCountry;
	}

	// Gets the animals reserved status
	public boolean getReserved() {
		return reserved;
	}

	// Sets the animals reserved status with the value passed in
	public void setReserved(boolean reserved) {
		this.reserved = reserved;
	}

	// Gets the animals service location
	public String getInServiceLocation() {
		return inServiceCountry; 
	}

	// Sets the animals service location with the value passed in
	public void setInServiceCountry(String inServiceCountry) {
		this.inServiceCountry = inServiceCountry;
	}

	// Gets the animals training status
	public String getTrainingStatus() {
		return trainingStatus;
	}

	// Sets the animals training status with the value passed in
	public void setTrainingStatus(String trainingStatus) {
		this.trainingStatus = trainingStatus;
	}
}
