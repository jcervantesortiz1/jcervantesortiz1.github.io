// IT-145 Project 2
// Juan Cervantes Ortiz 6/16/2023
import java.util.ArrayList; 
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    // Instance variables (if needed)

    // creates a new monkey array
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();

    public static void main(String[] args) {
 
        initializeDogList();
        initializeMonkeyList();

        // Add a loop that displays the menu, accepts the users input
        // and takes the appropriate action.
        // For the project submission you must also include input validation
        // and appropriate feedback to the user.
        // Hint: create a Scanner and pass it to the necessary
        // methods
        // Hint: Menu options 4, 5, and 6 should all connect to the printAnimals()
        // method.
        
        // creates scanner to read user input
        Scanner scan = new Scanner(System.in);
        // sets user input as input so that it can be compared
        char input;

        // do loop that will check input
        do {
            // runs the displayMenu method to show options
            displayMenu();
            // scans the value entered, it will also ignore other inputs aside from the first character
            input = scan.next().charAt(0);

            // switch cases that check input and run appropriate method
            switch (input) {
                case '1':
                    intakeNewDog(scan);
                    break;

                case '2':
                    intakeNewMonkey(scan);
                    break;

                case '3':
                    reserveAnimal(scan);
                    break;

                case '4':
                    printAnimals("dog");
                    break;

                case '5':
                    printAnimals("monkey");
                    break;

                case '6':
                    printAnimals("available");
                    break;

                // if the input is q it will notify the user and then end the program
                case 'q':
                    System.out.println("You have exited the application");
                    break;

                // any other input other than [1,2,3,4,5,6,q] will result in the error message and will loop back to the begining of do loop
                default:
                    System.out.println("Invalid option, enter valid option");
                    break;

            }
        // ensures that the do loop continues to run while input is NOT q
        } while (input != 'q');
    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }

    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake",
                false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false,
                "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true,
                "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }

    // Adds monkeys to a list for testing
    // Optional for testing
    public static void initializeMonkeyList() {
        Monkey monkey1 = new Monkey("M1", "Capuchin", "male", "2", "7.8", "04-24-2022", "United States", "in service",
                false, "United States", "14.8", "15.6", "17.2");
        Monkey monkey2 = new Monkey("M2", "Tamarin", "male", "3", "34.3", "02-12-2019", "Canada", "in service", true,
                "United States", "3 in", "24 in", "35 lbs");
        Monkey monkey3 = new Monkey("M3", "Tamarin", "male", "3", "34.3", "02-12-2019", "Canada", "in service", false,
                "Canada", "3 in", "24 in", "35 lbs");

        // adds monkey(s) to array
        monkeyList.add(monkey1);
        monkeyList.add(monkey2);
        monkeyList.add(monkey3);
    }

    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list
    // is done for you
    public static void intakeNewDog(Scanner scanner) {
        // clears out input so that the dogs name can be properly read in
        scanner.nextLine();
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        for (Dog dog : dogList) {
            if (dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; // returns to menu
            }
        }

        // Add the code to instantiate a new dog and add it to the appropriate list
        System.out.println("Enter dog's breed");
        String breed = scanner.nextLine();
        System.out.println("Gender: ");
        String gender = scanner.nextLine();
        System.out.println("Age: ");
        String age = scanner.nextLine();
        System.out.println("Weight: ");
        String weight = scanner.nextLine();
        System.out.println("Acquistion date: ");
        String acquisitionDate = scanner.nextLine();
        System.out.println("Acquisiton country: ");
        String country = scanner.nextLine();
        System.out.println("Training status: ");
        String trainingStatus = scanner.nextLine();
        System.out.println("Reserved? (1 for true 0 for false)");
        String reservedAns = scanner.nextLine();

        // this if else statement will check to see if reservedAns is true or false and set it accordingly        
        boolean reserved;
        if (reservedAns.equals(1)) {
            reserved = true;
        } else {
            reserved = false;
        }

        System.out.println("In service country: ");
        String countryServ = scanner.nextLine();

        // passes in values collected to create a new dog and adds the dog to the array
        Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, country, trainingStatus, reserved,
                countryServ);
        dogList.add(newDog);
    }

    // Complete intakeNewMonkey
    // Instantiate and add the new monkey to the appropriate list
    // For the project submission you must also validate the input
    // to make sure the monkey doesn't already exist and the species type is allowed
    public static void intakeNewMonkey(Scanner scanner) {

        // clears out the input so that the monkeys name can be read in properly
        scanner.nextLine();
        System.out.println("What is the monkey's name: ");
        String name = scanner.nextLine();
        for (Monkey monkey : monkeyList) {
            if (monkey.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis Monkey is already in our system\n\n");
                return; // returns to menu
            }
        }
        
        // info that will be collected to create new monkey in array
        System.out.println("What is the monkey's species?");
        String species = scanner.nextLine();
        // ensures that the species is permited or else it will say the species isnt allowed
        if (!(species.equalsIgnoreCase("Capuchin")) && !(species.equalsIgnoreCase("Guenon"))
                && !(species.equalsIgnoreCase("Macaque")) && !(species.equalsIgnoreCase("Marmoset"))
                && !(species.equalsIgnoreCase("Squirrel Monkey")) && !(species.equalsIgnoreCase("Tamarin"))) {
            System.out.println("\n\nThis monkey's species is not allowed\n\n");
        }

        // continues to collect the required info
        System.out.println("Gender: ");
        String gender = scanner.nextLine();
        System.out.println("Age: ");
        String age = scanner.nextLine();
        System.out.println("Weight: ");
        String weight = scanner.nextLine();
        System.out.println("Acquistion date: ");
        String acquisition = scanner.nextLine();
        System.out.println("Acquisiton country: ");
        String country = scanner.nextLine();
        System.out.println("Training status: ");
        String status = scanner.nextLine();
        System.out.println("Reserved? (1 for true 0 for false)");
        String reservedAns = scanner.nextLine();
        // this if else statement will check to see if reservedAns is true or false and set it accordingly
        boolean reserved;
        if (reservedAns.equals(1)) {
            reserved = true;
        } else {
            reserved = false;
        }

        System.out.println("In service country: ");
        String countryServ = scanner.nextLine();
        System.out.println("Taillength: ");
        String tailLength = scanner.nextLine();
        System.out.println("Height");
        String height = scanner.nextLine();
        System.out.println("body length");
        String bodyLength = scanner.nextLine();

        // passes in values collected  to create a new monkey and adds the monkey to the array
        Monkey newMonkey = new Monkey(name, species, gender, age, weight, acquisition, country, status, reserved,
                countryServ, tailLength, height, bodyLength);
        monkeyList.add(newMonkey);
    }

    // Complete reserveAnimal
    // You will need to find the animal by animal type and in service country
    public static void reserveAnimal(Scanner scanner) {
        // System.out.println("The method reserveAnimal needs to be implemented");
        scanner.nextLine();

        // collects the animal type and acquision country 
        System.out.println("Enter animal type (Dog or Monkey): ");
        String animalType = scanner.nextLine();
        System.out.println("Enter the animals acquision country: ");
        String country = scanner.nextLine();

        // checks for dog
        if (animalType.equalsIgnoreCase("dog")) {
            // loads dogList data
            for (Dog dog : dogList) {
                int i;
                // itterates through each index in dogList
                for (i = 0; i <= dogList.size();) {
                    // gets the dog in the index
                    dogList.get(i);
                    // checks that the dog is in service, dog is not reserved, and the country the dog is in is equal to country entered
                    if (true && dog.getInServiceLocation().equalsIgnoreCase(country)
                            && dog.getTrainingStatus().equalsIgnoreCase("in service") && !dog.getReserved()) {
                        // sets the dog reserved and outputs the dogs name that is now reserved
                        dogList.get(i).setReserved(true);
                        System.out.println(dog.getName() + " is now reserved");
                        break;
                    // if dog doesnt meet requirements it will go back to the next index
                    } else {
                        break;
                    }
                }
            }
        }

        // checks for monkey
        if (animalType.equalsIgnoreCase("monkey")) {
            // loads monkeyList data
            for (Monkey monkey : monkeyList) {
                int i;
                // itterates through each index in monkeyList
                for (i = 0; i <= monkeyList.size();) {
                    monkeyList.get(i);
                    // checks that the monkey is in service, monkey is not reserved, and the country the monkey is in is equal to country entered
                    if (true && monkey.getInServiceLocation().equalsIgnoreCase(country)
                            && monkey.getTrainingStatus().equalsIgnoreCase("in service") && !monkey.getReserved()) {
                        // monkey.setReserved(true);
                        monkeyList.get(i).setReserved(true);
                        System.out.println(monkey.getName() + " is now reserved");
                        break;
                    // if monkey doesnt meet requirements it will go back to the next index
                    }else {
                        break;
                    }
                    
                }
            }
        }
    }

    // Complete printAnimals
    // Include the animal name, status, acquisition country and if the animal is
    // reserved.
    // Remember that this method connects to three different menu items.
    // The printAnimals() method has three different outputs
    // based on the listType parameter
    // dog - prints the list of dogs
    // monkey - prints the list of monkeys
    // available - prints a combined list of all animals that are
    // fully trained ("in service") but not reserved
    // Remember that you only have to fully implement ONE of these lists.
    // The other lists can have a print statement saying "This option needs to be
    // implemented".
    // To score "exemplary" you must correctly implement the "available" list.
    public static void printAnimals(String input) {
        // System.out.println("The method printAnimals needs to be implemented");

        // if the user inputs 4, the system will pass in the string 'dog'
        if (input == "dog") {
            for (Dog dog : dogList) {
                // prints out the dog info
                System.out.println(dog.getName() + " " + dog.getTrainingStatus() + " " + dog.getAcquisitionLocation()
                        + " " + dog.getReserved());
            }
        // if the user inputs 5, the system will pass in the string 'monkey'
        }if (input == "monkey") {
            for (Monkey monkey : monkeyList) { 
                // prints out the monkeys info
                System.out.println(monkey.getName() + " " + monkey.getTrainingStatus() + " "
                        + monkey.getAcquisitionLocation() + " " + monkey.getReserved());
            }
        // if the user inputs 6, the system will pass in the string 'available'
        }if (input == "available") {
            // itterates through the dogs that are in service and are NOT reserved
            // also prints the name, training status, acquision location, and if the dog is reserved
            for (Dog dog : dogList) {
                if (dog.getTrainingStatus().equalsIgnoreCase("in service") && (dog.getReserved() == false))
                    System.out
                            .println(dog.getName() + " " + dog.getTrainingStatus() + " " + dog.getAcquisitionLocation()
                                    + " " + dog.getReserved());
            }
            // itterates through the monkeys that are in service and are NOT reserved
            // also prints the name, training status, acquision location, and if the monkey is reserved
            for (Monkey monkey : monkeyList) {
                if (monkey.getTrainingStatus().equalsIgnoreCase("in service") && (monkey.getReserved() == false))
                    System.out.println(monkey.getName() + " " + monkey.getTrainingStatus() + " "
                            + monkey.getAcquisitionLocation() + " " + monkey.getReserved());
            }
        }

    }
}
