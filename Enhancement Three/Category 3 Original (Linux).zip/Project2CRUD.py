#Juan Cervantes Ortiz
from pymongo import MongoClient
from bson.objectid import ObjectId
import pprint

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    # updated method so that it takes in the USER and PASS to connect to the database
    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        # 
        #USER = 'aacuser'
        #PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31762
        DB = 'AAC' 
        COL = 'animals'
        #
        # Initialize Connection 
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            createData = self.database.animals.insert_one(data)  # data should be dictionary
            # if the data is created successfully it will return true, otherwise false
            if createData!=0:
                return True
            else:
                return False
        # exception for if no data is passed in
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, findData):
        if findData is not None:
            data = self.database.animals.find(findData)
            #if data !=0:
                #return data
            #else: 
                #return "[]"
        # exception if no data is passed in
        else:
            data = self.database.animals.find({}) 
            #raise Exception("Invalid Search, no data passed in")
        return data

# Create Method to implement the U in CRUD
    def update(self, findData, updateData):
        if findData is not None:
            if findData:
                result = self.database.animals.update_one(findData, {"$set": updateData})
            return result.raw_result
        # exceotpion if no data is passed in
        else:
            raise Exception("Unable to Update, no data passed in")
        return result.raw_result
    
# Create method to implement the D in CRUD
    def delete(self, deleteData):
        if deleteData is not None:
            if deleteData:
                result = self.database.animals.delete_many(deleteData)
        # exception if no data is passsed in
        else: 
            raise Exception("Nothing to Delete, no data passed in")
        return result.raw_result